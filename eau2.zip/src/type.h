//lang cwc

#pragma once

/**
 * Enum of types that can be in a .sor file
 */
enum Type {
    BOOL,
    INT,
    DOUBLE,
    STRING
}; 